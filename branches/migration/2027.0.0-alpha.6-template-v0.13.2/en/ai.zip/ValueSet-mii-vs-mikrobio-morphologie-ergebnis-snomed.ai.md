# MII VS Mikrobio Morphologie Ergebnis [SNOMED] - MII Implementation Guide Microbiology v2027.0.0-alpha.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS Mikrobio Morphologie Ergebnis [SNOMED]**

## ValueSet: MII VS Mikrobio Morphologie Ergebnis [SNOMED] 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/ValueSet/mii-vs-mikrobio-morphologie-ergebnis-snomed | *Version*:2027.0.0-alpha.6 |
| Active as of 2026-09-02 | *Computable Name*:MII_VS_Mikrobio_Morphologie_Ergebnis_SNOMED |

 **References** 

* [MII PR Mikrobio Mikroskopie](StructureDefinition-mii-pr-mikrobio-mikroskopie.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-mikrobio-morphologie-ergebnis-snomed",
  "url" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/ValueSet/mii-vs-mikrobio-morphologie-ergebnis-snomed",
  "version" : "2027.0.0-alpha.6",
  "name" : "MII_VS_Mikrobio_Morphologie_Ergebnis_SNOMED",
  "title" : "MII VS Mikrobio Morphologie Ergebnis [SNOMED]",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-02T21:10:40+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "723529006",
        "display" : "Extracellular Gram-negative diplococcus (finding)"
      },
      {
        "code" : "404509004",
        "display" : "Large gram-negative coccobacilli (finding)"
      },
      {
        "code" : "404510009",
        "display" : "Large gram-negative rods (finding)"
      },
      {
        "code" : "427824002",
        "display" : "Small Gram-negative rods (finding)"
      },
      {
        "code" : "61609004",
        "display" : "Gram-positive cocci in chains (finding)"
      },
      {
        "code" : "70003006",
        "display" : "Gram-positive cocci in clusters (finding)"
      },
      {
        "code" : "734444009",
        "display" : "Gram-positive cocci in chains, clusters, and pairs (finding)"
      },
      {
        "code" : "734447002",
        "display" : "Intracellular Gram-negative diplococcus (finding)"
      },
      {
        "code" : "404507002",
        "display" : "Hyphae of kingdom Fungi detected (finding)"
      },
      {
        "code" : "768480006",
        "display" : "Branching hyphae of kingdom Fungi detected (finding)"
      },
      {
        "code" : "768488004",
        "display" : "Broad irregular hyphae of kingdom Fungi detected (finding)"
      },
      {
        "code" : "768479008",
        "display" : "Narrow hyphae of kingdom Fungi detected (finding)"
      },
      {
        "code" : "768481005",
        "display" : "Nonbranching hyphae of kingdom Fungi detected (finding)"
      },
      {
        "code" : "719645005",
        "display" : "Nonseptate hyphae of kingdom Fungi detected (finding)"
      },
      {
        "code" : "719644009",
        "display" : "Septate hyphae of kingdom Fungi detected (finding)"
      }]
    }]
  }
}

```
