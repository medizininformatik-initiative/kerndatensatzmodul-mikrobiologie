# mii-sp-mikrobio-interpretation - MII Implementation Guide Microbiology v2027.0.0-alpha.6

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-sp-mikrobio-interpretation**

## SearchParameter: mii-sp-mikrobio-interpretation 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/SearchParameter/Observation-norm-kategorie | *Version*:2027.0.0-alpha.6 |
| Active Stand: 2026-04-02 | *Maschinenlesbarer Name*:MII_SP_Mikrobio_NormKategorie |

 
Suchparameter für die Normkategorie der Empfindlichkeitsextension 



## Resource Content

```json
{
  "resourceType" : "SearchParameter",
  "id" : "mii-sp-mikrobio-interpretation",
  "url" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/SearchParameter/Observation-norm-kategorie",
  "version" : "2027.0.0-alpha.6",
  "name" : "MII_SP_Mikrobio_NormKategorie",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-02",
  "publisher" : "NUM-DIZ",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "NUM-DIZ"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "NUM-DIZ",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.netzwerk-universitaetsmedizin.de"
    }]
  }],
  "description" : "Suchparameter für die Normkategorie der Empfindlichkeitsextension",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "code" : "norm-kategorie",
  "base" : ["Observation"],
  "type" : "token",
  "expression" : "Observation.interpretation.extension('https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-ex-mikrobio-empfindlichkeit-norm').value.ofType(CodeableConcept)"
}

```
