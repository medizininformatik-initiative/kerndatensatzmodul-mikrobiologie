# mii-sp-mikrobio-interpretation - MII Implementation Guide Microbiology v2027.0.0-ballot2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-sp-mikrobio-interpretation**

## SearchParameter: mii-sp-mikrobio-interpretation 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/SearchParameter/Observation-norm-kategorie | *Version*:2027.0.0-ballot2 |
| Active as of 2026-04-02 | *Computable Name*:MII_SP_Mikrobio_NormKategorie |

 
Search parameter for the norm category of the susceptibility extension 



## Resource Content

```json
{
  "resourceType" : "SearchParameter",
  "id" : "mii-sp-mikrobio-interpretation",
  "url" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/SearchParameter/Observation-norm-kategorie",
  "version" : "2027.0.0-ballot2",
  "name" : "MII_SP_Mikrobio_NormKategorie",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-02",
  "publisher" : "Medizininformatik Initiative",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "Medizininformatik Initiative"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "description" : "Search parameter for the norm category of the susceptibility extension",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "code" : "norm-kategorie",
  "base" : ["Observation"],
  "type" : "token",
  "expression" : "Observation.interpretation.extension('https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-ex-mikrobio-empfindlichkeit-norm').value.ofType(CodeableConcept)"
}

```
