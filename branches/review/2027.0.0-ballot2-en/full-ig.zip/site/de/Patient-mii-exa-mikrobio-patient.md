# MII EXA Microbiology Patient - MII Implementation Guide Microbiology v2027.0.0-ballot2

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII EXA Microbiology Patient**

## Beispiel Patient: MII EXA Microbiology Patient

-------

**German**

-------

Anonymous Patient (no stated gender), DoB Unknown ( https://example.org/fhir/sid/test-patient#111)

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "mii-exa-mikrobio-patient",
  "identifier" : [{
    "system" : "https://example.org/fhir/sid/test-patient",
    "value" : "111"
  }]
}

```
