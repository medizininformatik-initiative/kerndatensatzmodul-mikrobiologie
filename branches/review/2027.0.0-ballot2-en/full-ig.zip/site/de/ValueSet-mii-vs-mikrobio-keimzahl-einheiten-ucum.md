# MII VS Microbiology Colony Count Units [UCUM] - MII Implementation Guide Microbiology v2027.0.0-ballot2

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII VS Microbiology Colony Count Units [UCUM]**

## ValueSet: MII VS Microbiology Colony Count Units [UCUM] 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/ValueSet/mii-vs-mikrobio-keimzahl-einheiten-ucum | *Version*:2027.0.0-ballot2 |
| Active Stand: 2023-03-02 | *Maschinenlesbarer Name*:MII_VS_Mikrobio_Keimzahl_Einheiten_UCUM |

 
Unit ValueSet for colony counting (UCUM): colony-forming units per volume, per mass or as a count per specimen. 

 **References** 

* [MII PR Microbiology Colony Count](StructureDefinition-mii-pr-mikrobio-keimzahl.md)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-mikrobio-keimzahl-einheiten-ucum",
  "url" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/ValueSet/mii-vs-mikrobio-keimzahl-einheiten-ucum",
  "version" : "2027.0.0-ballot2",
  "name" : "MII_VS_Mikrobio_Keimzahl_Einheiten_UCUM",
  "title" : "MII VS Microbiology Colony Count Units [UCUM]",
  "status" : "active",
  "experimental" : false,
  "date" : "2023-03-02T00:00:00Z",
  "publisher" : "Medizininformatik Initiative",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "Medizininformatik Initiative"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "description" : "Unit ValueSet for colony counting (UCUM): colony-forming units per volume, per mass or as a count per specimen.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://unitsofmeasure.org",
      "concept" : [{
        "code" : "[CFU]/mL"
      },
      {
        "code" : "[CFU]/g"
      },
      {
        "code" : "[CFU]"
      },
      {
        "code" : "[arb'U]/mL"
      },
      {
        "code" : "/g"
      },
      {
        "code" : "/mL"
      },
      {
        "code" : "1"
      }]
    }]
  }
}

```
