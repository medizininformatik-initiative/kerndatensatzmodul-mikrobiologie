# MII VS Microbiology Avidity Tests [LOINC] - MII Implementation Guide Microbiology v2027.0.0-ballot2

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII VS Microbiology Avidity Tests [LOINC]**

## ValueSet: MII VS Microbiology Avidity Tests [LOINC] 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/ValueSet/mii-vs-mikrobio-aviditaet-tests-loinc | *Version*:2027.0.0-ballot2 |
| Active Stand: 2026-10-19 | *Maschinenlesbarer Name*:MII_VS_Mikrobio_Aviditaet_Tests_LOINC |

 
Test ValueSet for avidity determination: LOINC codes for avidity tests including the target antigen. 

 **References** 

* [MII PR Microbiology Avidity](StructureDefinition-mii-pr-mikrobio-aviditaet.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-mikrobio-aviditaet-tests-loinc",
  "url" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/ValueSet/mii-vs-mikrobio-aviditaet-tests-loinc",
  "version" : "2027.0.0-ballot2",
  "name" : "MII_VS_Mikrobio_Aviditaet_Tests_LOINC",
  "title" : "MII VS Microbiology Avidity Tests [LOINC]",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T02:33:36+00:00",
  "publisher" : "Medizininformatik Initiative",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "Medizininformatik Initiative"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "description" : "Test ValueSet for avidity determination: LOINC codes for avidity tests including the target antigen.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "version" : "2.82",
      "concept" : [{
        "code" : "52984-2",
        "display" : "Cytomegalovirus IgG Ab avidity [Ratio] in Serum or Plasma by Immunoassay"
      },
      {
        "code" : "81119-0",
        "display" : "Epstein Barr virus capsid IgG Ab avidity [Ratio] in Serum by Immunoassay"
      },
      {
        "code" : "104428-8",
        "display" : "Measles virus IgG Ab avidity [Ratio] in Serum by Immunoassay"
      },
      {
        "code" : "52986-7",
        "display" : "Rubella virus IgG Ab avidity [Ratio] in Serum by Immunoassay"
      },
      {
        "code" : "56990-5",
        "display" : "Toxoplasma gondii IgG Ab avidity [Ratio] in Serum by Immunoassay"
      }]
    }]
  }
}

```
