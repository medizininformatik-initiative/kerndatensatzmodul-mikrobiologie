# Home - MII Implementation Guide Microbiology v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/ImplementationGuide/mii-ig-mikrobiologie | *Version*:2027.0.0-ballot.rc1 |
| Active as of 2026-09-11 | *Computable Name*:MII_IG_Mikrobiologie |

### Introduction

This specification describes the FHIR representation of the Core Dataset (CDS) module **Microbiology** of the Medical Informatics Initiative (MII). It covers the module's use cases and the associated FHIR profiles, extensions and terminology resources in their normative form. The MII Core Dataset enables the standardized secondary use of routine clinical data for medical research.

The module describes the investigations carried out in laboratories to detect, identify and characterise microorganisms and their properties. It is of decisive importance because it forms the basis for a common investigation of infectious diseases and antibiotic resistance, which lead to global health emergencies and are among the main priorities of the [WHO](http://www.who.int).

**Note on the state of the underlying model.** In the course of a harmonisation process between the RKI, MIO42 and the MII, the microbiology data model was fundamentally revised, and the agreements were extended to the European context (EHDS).

That European model is **not yet final**. This release represents its current state as faithfully as an implementable specification allows: where the underlying agreements leave a question open, this guide states the decision it took and why. Points deliberately left open are listed under [Ballot questions](#ballot-questions), and we ask for comment on them. Implementers should expect changes in the areas concerned.

### Target audience

##### Implementers

For data management and integration in data integration centres (DIC), software developers and system architects building FHIR-based solutions.

* → [Profiles](profiles.md) — the normative constraints
* → [Guidance for Implementers](implementer-guidance.md) — conformance, artifacts, validation
* → [Logical Models](logical-models.md) and [UML Diagrams](uml-diagrams.md) — the conceptual view

##### Researchers

For scientists working with MII data.

* → [Guidance for Researchers](researcher-guidance.md) — where to start
* → [Profile Selection and Delimitation](profilauswahl-und-abgrenzung.md) — which profile carries which statement, and what a negative result means
* → [Examples](examples.md) — what the data looks like in practice

The Microbiology 2027 extension module models microbiological findings as standalone Observations. The main domains are:

* Culture (general, microscopy including Bartlett/Nugent score, colony count, susceptibility)
* Determination (general/specific, Ct value)
* Quantitative tests (antigen/antibody, titre, molecular pathogen load)
* Further properties (virulence, resistance mechanism, MRGN, predicted susceptibility, resistance category status, avidity)

Components of Observations were moved into separate profiles in this version.

| | |
| :--- | :--- |
| Date | not yet published |
| Version | 2027.0.0-ballot.rc1 (CalVer`YYYY.n.n`) |
| Status | active |
| Realm | DE |

### Ballot questions

This is a ballot candidate. The points below are deliberately left open, and we ask for comment on them during the ballot. Each is stated in full on the page it belongs to.

1. **[Is a Specimen resource always available?](probe.md#ballot-question-1)**— every investigation profile in this module requires`Observation.specimen`.
1. **[Can the staining technique be represented via `Specimen` alone?](StructureDefinition-mii-pr-mikrobio-mikroskopie.md#ballot-question-2)**— the European data model places it in`Specimen.processing`; we ask whether that is implementable.
1. **[Mandatory storage temperature conditions on `Specimen.processing`](probe.md#ballot-question-3)**— inherited from the biobank base profile, without meaning for microbiological processing.
1. **[Is incubation duration and temperature representable via `Specimen.processing`?](probe.md#ballot-question-4)**— FHIR and the MII provide the pieces; the question is whether sites can supply them.
1. **[Component or `hasMember` for a semiquantitative amount?](StructureDefinition-mii-pr-mikrobio-mikroskopie.md#ballot-question-5)**— the European data model leaves this open; a component reverses a decision of this release cycle.
1. **[Can you supply `Observation.method` for every result?](profilauswahl-und-abgrenzung.md#ballot-question-6)**— the white paper asks for it always; this guide only recommends it, and your answer decides more than one question.
1. **[Should specific culture and specific determination be one profile?](StructureDefinition-mii-pr-mikrobio-spezifische-kultur.md#ballot-question-7)**— they were until`2027.0.0-alpha.5`, the European discussion is open, and merging is free only until this release is published.

### Contents

* **[Guidance](guidance.md)** — getting started and domain notes.
* **Conformance** — the KDS-wide conformance rules (requirements language, Must Support, handling missing data) are maintained centrally by the [Meta module](https://github.com/medizininformatik-initiative/kerndatensatz-meta/wiki/Conformance); the module-specific [Security and Privacy](security-and-privacy.md) considerations are part of this guide.
* **[Profiles](profiles.md)** and the further **[artifact pages](artifacts.md)** — the technical artifacts.
* **[Examples](examples.md)** — example instances.
* **[Dependencies](ImplementationGuide-mii-ig-mikrobiologie.md)** — the ImplementationGuide resource with the dependency table, cross-version analysis and copyright statements.

### Related guides

This module is part of the MII Core Dataset; the other KDS modules and their dependencies are described at [medizininformatik-initiative.de](https://www.medizininformatik-initiative.de/).

This module builds on the [KDS module Laboratory report](https://simplifier.net/medizininformatikinitiative-modullabor); the formal dependency is declared as `de.medizininformatikinitiative.kerndatensatz.laborbefund` in `sushi-config.yaml`. The relations to the Molecular genetic report, Biobank, Case and Structural data modules are described on [Guidance for Implementers](implementer-guidance.md).

### Imprint

This guide was created within the Medical Informatics Initiative and is subject, by its governance process, to the coordination procedure of the Interoperability Forum and the technical committees of HL7 Germany.

### Contact

Questions about this publication can be asked on the HL7 FHIR Zulip [chat.fhir.org](https://chat.fhir.org) in the `german/mi-initiative` stream, or on the MII Zulip [mii.zulipchat.com](https://mii.zulipchat.com/) in the `MII-Kerndatensatz` stream. Comments and issues are welcome as **Issues** on [GitHub](https://github.com/medizininformatik-initiative/kerndatensatzmodul-mikrobiologie/issues).

* Eugenia Rinaldi, Charité
* Karoline Buckow, TMF - Technologie- und Methodenplattform für die vernetzte medizinische Forschung e. V.

### Authors (in alphabetical order)

* Claas Baier (Medizinische Hochschule Hannover)
* Martin Boeker (TU München)
* Karoline Buckow (MII-Koordinationsstelle)
* Cora Drenkhahn (Universität zu Lübeck)
* Benjamin Gebel (Universitätsklinikum Schleswig-Holstein)
* Ludwig Christian Hinske (Universitätsklinikum Augsburg)
* Franziska Klepka (MII-Koordinationsstelle)
* Eugenia Rinaldi (Charité Berlin / BIH)
* Norbert Thoma (Charité Berlin / Institut für Hygiene und Umweltmedizin)
* Kutaiba Saleh (Universitätsklinikum Jena)
* Hauke Tönnies (Universitätsklinikum Münster)
* Patrick Werner (HL7 Deutschland)
* Alexander Zautke (HL7 Deutschland)

### Copyright and License

© 2019+ TMF e. V., Charlottenstraße 42, 10117 Berlin

This work is licensed under the [Creative Commons Attribution 4.0 International License (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/).

For the usage rights of the underlying FHIR technology, see the FHIR base specification.

Some of the code systems used are published and maintained by other organizations; the copyright of the respective publishers applies.

### Disclaimer

The content of this document is public. Please note that parts of this document are based on FHIR version R4, which is copyrighted by HL7 International.

Although this publication was prepared with the greatest care, the authors cannot accept any liability for direct or indirect damage that may arise from the content of this specification.

