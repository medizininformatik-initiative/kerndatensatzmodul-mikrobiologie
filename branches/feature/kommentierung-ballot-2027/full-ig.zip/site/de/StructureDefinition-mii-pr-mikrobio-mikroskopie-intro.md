<!-- MIGRATED verbatim from Simplifier page: MIIIGModulMikrobiologie/Technische-Implementierung/FHIR-Profile/Kultur/Mikroskopie.page.md  -->
Allgemeine Mikroskopie beschreibt die morphologische Beobachtung von Mikroorganismen in einer Probe mittels mikroskopischer Untersuchung, optional mit Färbetechniken (z. B. Gramfärbung). Das Ergebnis ist eine morphologische Gruppe, keine Spezies.

Sie ist die offene Hälfte der Mikroskopie: Der Code fragt, was zu sehen ist, und
die Antwort ist die beobachtete Morphologie. Steht das gesuchte Objekt bereits im
Untersuchungscode und ist die Antwort, wie viel davon gesehen wurde, ist
[Spezifische Mikroskopie](StructureDefinition-mii-pr-mikrobio-spezifische-mikroskopie.html)
das richtige Profil.

### Färbung

Die Färbung steht in `extension[faerbung]`, codiert mit den Nachkommen von
`37926009 |Microbial stain method (procedure)|` — denselben Codes, die die HL7 EU
Lab Semantic Workgroup verwendet. Sie wird immer angegeben, wenn gefärbt wurde,
auch dann, wenn der Untersuchungscode sie schon nennt: Sie ist damit an einer
Stelle auswertbar, unabhängig davon, welchen Code ein Labor wählt.
`Observation.method` trägt nur noch das Mikroskopieverfahren — bei nativer
Mikroskopie ohne Färbung die einzige Angabe, die zu machen ist.

<a id="staining"></a>

### Färbung an der Observation

Die Färbung steht in `extension[faerbung]`, nicht wie bei der HL7 EU Lab
Semantic Workgroup in `Specimen.processing`; die Codes sind dieselben. Grund: Eine
Probe wird oft mehrfach gefärbt, ohne dass das LIS Unterproben anlegt. Nur an der
Observation bleibt erkennbar, welche Färbung zu welchem Befund gehört. Für das
EU-Modell wird je Färbung eine abgeleitete Probe angelegt.

### Morphologie zusammen mit ihrer Menge

Der häufigste Grambefund braucht zwei Aussagen auf einmal — *wenig* grampositive
Kokken —, und `value[x]` kann nur eine davon tragen. Die Morphologie ist der Wert,
die Menge eine Komponente: `component[menge]`. Dieselbe Komponente, mit demselben
Code und denselben Antworten, trägt die Menge in der
[Spezifischen Mikroskopie](StructureDefinition-mii-pr-mikrobio-spezifische-mikroskopie.html).

Ihr Code ist `103392008 |Semi-quantitative value|`, das Konzept, das die HL7 EU
Lab Semantic Workgroup für diese Komponente vorschlägt. Für denselben Zweck ist
ein LOINC-Code angefordert; er tritt an diese Stelle, sobald er existiert. Neben
dem semiquantitativen Wert nimmt die Komponente eine Zählung je Gesichtsfeld,
als `Quantity` oder als `Range`.

### Beispiele

Beispiel (minimal):

[mii-exa-mikrobio-mikroskopie](Observation-mii-exa-mikrobio-mikroskopie.html)
